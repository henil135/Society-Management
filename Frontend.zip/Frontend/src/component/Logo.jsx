import React from 'react'

const Logo = () => {
    return (
        <div>
            <h1 className='stack mt-5 '>
                <span style={{ color: '#ee6a42' }}>Dash</span>Stack
            </h1>
        </div>
    )
}

export default Logo

